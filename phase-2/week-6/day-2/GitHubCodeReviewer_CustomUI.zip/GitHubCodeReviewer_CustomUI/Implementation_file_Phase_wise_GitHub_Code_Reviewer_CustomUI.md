# GitHub Code Reviewer Agent — Human Product Prompt Master Roadmap 🚀
> **For AI Trainers & Learners**: This document gives a step-by-step prompt roadmap to build a branded, custom web dashboard for an existing **GitHub Code Reviewer Agent** built in n8n. Every prompt is written naturally from a human user's point of view, with no file names, style-class names or heavy technical jargon. Replace the **[BRACKETED FIELDS]** with your own organization's details.

---

## 📌 How to Use This Roadmap
1. Fill in the **Branding Customization Sheet** below. Every phase uses these details.
2. Complete **Phase 0** first. It prepares the n8n workflow so a web page can talk to it.
3. Follow **Phases 1 to 7** in order. Copy the prompt inside each **"📋 Copy-Paste Prompt for AI Assistant"** and paste it into your AI coding tool, replacing the bracketed fields.
4. After each phase, run the **"🧪 User-Facing Verification Steps"** in your browser before moving on.
5. The AI handles file creation, folder structure, styling and logic. Your job is to describe what you want and to check the result.

---

## 🎨 Branding Customization Sheet (fill this in first)

| Item | Your value | Example (replace with yours) |
|---|---|---|
| Organization name | [ORGANIZATION NAME] | "Acme Technologies" |
| Short product name | [PRODUCT NAME] | "CodeLens Reviewer" |
| Tagline | [TAGLINE] | "Better code, shipped faster." |
| Logo | [LOGO: image file or initials badge] | A square logo, or a rounded badge with the letters "AT" |
| Primary brand colour | [PRIMARY COLOUR] | Deep indigo |
| Secondary colour | [SECONDARY COLOUR] | Teal |
| Accent colour | [ACCENT COLOUR] | Amber |
| Success / Warning / Error colours | [STATUS COLOURS] | Green / Amber / Red |
| Page style | [LIGHT, DARK, or BOTH] | Light by default, with a dark option |
| Heading font / body font / code font | [FONTS] | A modern geometric font / a clean sans-serif / a monospace font |
| Support contact | [SUPPORT EMAIL OR LINK] | support@your-organization.example |
| Footer links | [FOOTER LINKS] | Privacy Policy, Terms, Documentation, Contact |
| Copyright line | [COPYRIGHT TEXT] | "© 2026 [Organization]. All rights reserved." |

> 💡 **Tip:** If you do not have an official logo, ask the AI to create a simple initials badge in your brand colours. Use only fonts and images you are allowed to use.

---

## 🔌 Planned Request / Response Contract (used by Phases 0, 5 and 6)

> ⚠️ **Adjust this to match what your existing agent actually expects.** The fields below are a sensible default for a pull-request reviewer.

**What the page sends (JSON):**
```json
{
  "prUrl": "https://github.com/owner/repository/pull/123",
  "focusAreas": ["quality", "security", "performance", "tests"]
}
```

**What the page expects back:** the review as markdown text. It can arrive as plain text, a JSON object with a text field such as `review` or `output`, or a nested array. The page must cope with all of these.

---

## Phase 0: Prepare the n8n Workflow (Webhook In, Respond Out)

### 🎯 Phase Goal
Turn the existing GitHub Code Reviewer Agent into a service a web page can call. The agent logic stays the same. You add a **Webhook** node at the start and a **Respond to Webhook** node at the end.

### 🛠️ Steps (done by you in n8n)
1. **Open** the existing GitHub Code Reviewer Agent workflow. Duplicate it first as a backup.
2. **Add a Webhook node as the very first node** and set it to:
   - HTTP Method: **POST**
   - Path: a clear name such as `github_code_reviewer`
   - Respond: **Using 'Respond to Webhook' Node**
   - Under Options, add **Allowed Origins (CORS)** and enter the address your UI will run from (use `*` only for local practice).
3. **Connect the data.** The webhook puts the request data under its `body` field, so the pull request link is available as `{{ $json.body.prUrl }}`. Point the agent's input (and any GitHub-fetching step) at that value instead of the old trigger's value.
4. **Add a Respond to Webhook node as the very last node**, connected after the agent's final output. Set it to return JSON, for example with a field named `review` that holds the agent's text output (`{{ $json.output }}`).
5. **Make sure every branch ends at the Respond node**, including any error or "no changes found" branch. Otherwise the web page waits forever.
6. **Keep secrets in n8n.** GitHub tokens and AI keys must stay in n8n credentials. Never place them in the web page.
7. **Test and publish.**
   - While building, use the **Test URL** (it contains `webhook-test`) and click "Listen for test event" in the editor.
   - For the real UI, publish or activate the workflow and use the **Production URL** (it contains `webhook`).

### 🧪 Verification Steps
* [ ] Send a test POST request with a tool like Postman or curl, using a real pull request link in the `prUrl` field.
* [ ] The response arrives with the review text and a success status.
* [ ] Sending an empty or invalid body gives a clear error response, not a hung request.
* [ ] The workflow's execution list shows the Webhook as the first node and Respond to Webhook as the last.

---

## Phase 1: Creating the Application & Branded Visual Design System

### 🎯 Phase Goal
Create the base page and a reusable brand theme (colours, fonts, spacing, buttons) so the whole product looks like it belongs to your organization.

### 📋 Copy-Paste Prompt for AI Assistant
```text
Build the foundation for a professional web dashboard called "[PRODUCT NAME]" for [ORGANIZATION NAME]. It is a GitHub Code Reviewer: users paste a pull request link and receive an AI-generated code review.

Create a clean, modern, enterprise-grade design based on these brand details:
- Primary colour: [PRIMARY COLOUR], secondary colour: [SECONDARY COLOUR], accent colour: [ACCENT COLOUR]
- Success, warning and error colours: [STATUS COLOURS]
- Page style: [LIGHT, DARK, or BOTH]
- Fonts: [HEADING FONT] for headings, [BODY FONT] for text, [CODE FONT] for code

Keep all brand details (organization name, product name, tagline, logo, colours, fonts) in one easy-to-edit place at the top, so a different organization could re-brand the whole page by changing only those values.

Use generous spacing, soft rounded corners, subtle shadows, consistent button and input styles, and good text contrast. Add polished thin scrollbars in the brand colour. The page must look good on desktop, tablet and mobile screens.
```

### 🧪 User-Facing Verification Steps
* [ ] Open the page in a browser and confirm it uses your brand colours and fonts.
* [ ] Change the organization name or primary colour in the single brand settings area and confirm the whole page updates.
* [ ] Resize the browser window and confirm nothing overflows or overlaps.

---

## Phase 2: Professional Header & Footer

### 🎯 Phase Goal
Add a branded header with logo, navigation and connection status, and a professional footer with organization details and useful links.

### 📋 Copy-Paste Prompt for AI Assistant
```text
Add a professional, sticky header and a footer to the dashboard.

Header:
- On the left, show the [ORGANIZATION NAME] logo ([LOGO]) next to the product name "[PRODUCT NAME]" and the tagline "[TAGLINE]" in smaller text.
- In the middle, add navigation links: "Dashboard" (active), "Review History", "Guidelines", and "Help".
- On the right, add a status badge that shows "Reviewer Online" with a green pulsing dot when the review service responds, and "Reviewer Offline" in red when it does not. Add a circular user avatar showing the initials "[USER INITIALS]".
- On mobile, collapse the navigation into a tidy menu button, and keep the logo and status visible.

Footer:
- Show the organization logo and name, the copyright line "[COPYRIGHT TEXT]", the links [FOOTER LINKS], the support contact [SUPPORT EMAIL OR LINK], and a small version label such as "v1.0".
- Add a short note: "AI-generated reviews are advisory. Always verify before merging."
- On mobile, stack the footer content neatly in one column.
```

### 🧪 User-Facing Verification Steps
* [ ] Scroll the page and confirm the header stays at the top while the footer sits at the bottom of the content.
* [ ] Confirm the logo, organization name, product name and tagline appear correctly.
* [ ] Hover over the navigation links and confirm there is a clear highlight.
* [ ] Shrink the window to phone size and confirm the menu collapses and the footer stacks without overlap.
* [ ] Confirm the footer shows your copyright line, links, support contact and the advisory note.

---

## Phase 3: Responsive Dashboard Layout, Request Panel & Summary Cards

### 🎯 Phase Goal
Build the main layout: a request panel on the left where users describe what to review, and a large workspace on the right, plus summary cards across the top.

### 📋 Copy-Paste Prompt for AI Assistant
```text
Create a responsive dashboard with a request panel on the left and a main workspace on the right.

Left request panel (a card titled "Code Review Request"):
- A text field with a GitHub icon for the pull request link, with the placeholder "https://github.com/owner/repository/pull/123" and a short help line underneath.
- A group of checkboxes for review focus, all ticked by default: "Code Quality & Best Practices", "Security Vulnerabilities", "Performance", and "Test Coverage".
- A full-width primary button labelled "Review Pull Request" with a clear hover and pressed effect.
- Below it, a small card with tips such as "Use the full pull request link" and "Never paste passwords or secret keys".

Right workspace, at the top: three summary cards showing "PRs Reviewed", "Average Quality Score", and "Critical Issues Found". Use sample numbers for now and make each card use a different brand-coloured icon.

Layout rules: on desktop show two columns, on tablet make the request panel sit above a wider workspace, and on mobile stack everything in one column with comfortable tap sizes. Respect the organization branding throughout.
```

### 🧪 User-Facing Verification Steps
* [ ] Desktop: the request panel is on the left and the workspace on the right.
* [ ] Tablet width (about 768 px): the panel moves above the workspace and nothing is cut off.
* [ ] Mobile width (about 375 px): everything is one column and buttons are easy to tap.
* [ ] Click into the pull request field and confirm a visible focus outline in the brand colour.
* [ ] Confirm all four focus checkboxes are ticked by default and the three summary cards show icons and numbers.

---

## Phase 4: Review Workspace with Waiting, Loading, Success and Error States

### 🎯 Phase Goal
Design every visual state the workspace can be in, so users always know what is happening.

### 📋 Copy-Paste Prompt for AI Assistant
```text
In the right workspace, build a large card titled "Review Workspace" that can show five different states:

1. Waiting: a friendly illustration or icon in the brand colours, with the message "Paste a pull request link and click Review Pull Request to begin."
2. Loading: an animated scanning effect or progress bar in the brand colour, a rotating status message area, and a "This can take up to a minute" reassurance line. Show soft placeholder shapes (skeleton blocks) where the report will appear.
3. Success: a green "Review Complete" badge in the card header and space for the formatted report.
4. Validation problem: a small inline message under the input field with a red outline and a warning icon, and a brief shake of the card.
5. Error: a clear error card with an icon, a plain-language explanation, a "Try Again" button, and a "Contact Support" link.

Include smooth transitions between states. Respect users who prefer reduced motion by turning off heavy animations for them.
```

### 🧪 User-Facing Verification Steps
* [ ] The waiting state appears by default with the friendly message.
* [ ] Use any preview option or temporary switch your AI tool gave you to show each of the five states and confirm each looks distinct and on-brand.
* [ ] The error card has a "Try Again" button and a support link.
* [ ] With the device set to "reduce motion", confirm the animations are calmer.

---

## Phase 5: Input Validation, Webhook Connection & Error Handling

### 🎯 Phase Goal
Make the form work: check the user's input, show progress, call the n8n webhook, and handle every kind of failure without breaking the page.

### 📋 Copy-Paste Prompt for AI Assistant
```text
Make the dashboard fully interactive and connect it to an n8n workflow endpoint at /webhook/github_code_reviewer. Keep the endpoint address in the single brand and settings area so it is easy to change.

When a user clicks "Review Pull Request" or presses Enter in the link field:

1. Validate the input first:
   - If it is empty, show "Please enter a pull request link."
   - If it is not a valid GitHub pull request link in the form https://github.com/owner/repository/pull/number, show "That doesn't look like a GitHub pull request link. Example: https://github.com/owner/repository/pull/123."
   - If no review focus is ticked, show "Select at least one review focus."
   - On any problem, outline the field in red, show the message, and shake the card briefly. Do not contact the server.
2. If everything is valid, disable the form, change the button to "Reviewing...", and switch the workspace to the loading state.
3. Rotate friendly progress messages every 1.5 seconds, such as "Reading pull request...", "Fetching changed files...", "Checking code quality...", "Scanning for security risks...", "Preparing recommendations...".
4. Send a POST request containing the pull request link and the selected focus areas as JSON.
5. Stop waiting after 3 minutes and show a timeout message.
6. Handle problems gracefully with plain-language messages:
   - Server unreachable or no internet: "We couldn't reach the review service. Please check your connection and try again."
   - Server error (5xx): "The review service had a problem. Please try again in a moment."
   - Request rejected (4xx): show the helpful reason if one is provided.
   - Empty or unreadable response: "The review came back empty. Please try again."
   Always show the "Try Again" button and re-enable the form.
7. Accept the response in any common shape: plain text, a JSON object with a review or output text field, or a nested array. Pull out the review text from whichever shape arrives.
8. Never put passwords, tokens, or API keys in the page.
```

### 🧪 User-Facing Verification Steps
* [ ] **Empty input:** click the button with nothing typed. The field turns red, the message appears, and the card shakes.
* [ ] **Wrong link:** enter `hello` or a GitHub repository link without `/pull/`. The format message appears and no request is sent.
* [ ] **No focus area:** untick all boxes. The warning appears.
* [ ] **Valid link:** enter a real pull request link and submit. The form locks, the button says "Reviewing...", and the status messages change every 1.5 seconds.
* [ ] **Network check:** open the browser developer tools, go to the Network tab, submit again, and confirm a POST request goes to the review endpoint with the right JSON.
* [ ] **Failure check:** temporarily stop the n8n workflow or change the endpoint address and confirm the friendly error card, the "Try Again" button, and an unlocked form.

---

## Phase 6: Beautiful Review Report Display & Result Actions

### 🎯 Phase Goal
Convert the AI's markdown text into a clean, readable, branded report with severity labels and handy actions.

### 📋 Copy-Paste Prompt for AI Assistant
```text
Add automatic formatting so the AI's review appears as a clean, professional report inside the workspace, without relying on external libraries.

Convert the markdown text into well-structured content:
- Section headings in the brand colours, with clear size differences between levels.
- Bold and italic text, bullet and numbered lists, and links that open in a new tab.
- Code blocks in dark monospace boxes with a language label and a "Copy" button on each block.
- Markdown tables as neat tables with brand-coloured headers, alternating rows, and horizontal scrolling on small screens.
- Short inline code snippets with a soft background.

Make findings easy to scan: wherever the text mentions Critical, High, Medium, Low, or Info severity, show it as a coloured badge (red, orange, amber, blue, grey).

When the review finishes:
- Show the green "Review Complete" badge in the workspace header and fade the report in smoothly.
- Show the pull request link and the time the review finished at the top of the report.
- Add action buttons: "Copy Report", "Download Report" (as a markdown file), "Print / Save as PDF", and "New Review".
- Re-enable the form so the user can review another pull request.
- Update the summary cards if the report contains clear numbers (otherwise keep the sample values).
Make the report easy to read on phones, with comfortable line lengths and no sideways scrolling except inside tables and code blocks.
```

### 🧪 User-Facing Verification Steps
* [ ] After a successful review, the "Review Complete" badge appears and the report fades in.
* [ ] Headings, bold text, bullet lists, code blocks and tables look clean and use your brand colours.
* [ ] Severity words appear as coloured badges.
* [ ] "Copy" on a code block copies just that code. "Copy Report" copies the full text.
* [ ] "Download Report" saves a markdown file and "Print / Save as PDF" opens a clean printable view.
* [ ] "New Review" clears the report and the form is ready again.
* [ ] On a phone-sized screen, the report is readable and wide tables scroll sideways inside their own area.

---

## Phase 7: Organization Enhancements, Accessibility & Final Polish

### 🎯 Phase Goal
Add the finishing touches that make this feel like an internal company product: history, theme choice, accessibility, and quality checks.

### 📋 Copy-Paste Prompt for AI Assistant
```text
Add these finishing touches to the dashboard, keeping everything consistent with the [ORGANIZATION NAME] brand:

1. Review History page or panel: keep the last 10 reviews in the user's browser, showing the pull request link, date and time, and status. Let the user reopen a past report or clear the history. Add a note that history is stored only on this device.
2. Light and dark theme switch in the header, remembering the user's choice and defaulting to their device preference.
3. A welcome strip or short "How it works" guide with three steps: paste the link, choose focus areas, read the review.
4. A privacy and safety notice near the form: "Do not include secrets or confidential credentials."
5. Accessibility: readable contrast, labels on all fields, visible keyboard focus, full keyboard use (Enter to submit, Escape to close menus), status messages announced to screen readers, and support for larger text sizes.
6. Browser tab title and icon using the organization branding, and sensible page descriptions for sharing.
7. Friendly empty states, a clear "Reviewer Online/Offline" check that refreshes every minute, and a subtle toast message for actions such as "Report copied".
8. A tidy print layout that shows only the report with the organization name and date.
9. Make sure the layout is correct at phone, tablet, laptop, and wide-monitor sizes.
```

### 🧪 User-Facing Verification Steps
* [ ] Complete two reviews, then open Review History and confirm both appear and can be reopened or cleared.
* [ ] Switch between light and dark themes, reload the page, and confirm the choice is remembered.
* [ ] Use only the keyboard (Tab, Enter, Escape) to run a review from start to finish.
* [ ] Check the browser tab shows your organization's title and icon.
* [ ] Open the page at phone, tablet and desktop widths and confirm all pages look right.
* [ ] Print the report and confirm only the report with your organization name and date appears.

---

## ✅ Final End-to-End Acceptance Checklist
* [ ] The n8n workflow starts with a **Webhook** node and ends with a **Respond to Webhook** node, and every path returns a response.
* [ ] The page shows your organization name, logo, colours, fonts, header and footer.
* [ ] Validation messages appear for an empty field, a wrong link and no focus area.
* [ ] Loading, success and error states all look correct and are easy to understand.
* [ ] A real pull request produces a formatted report with code blocks, tables and severity badges.
* [ ] The page works at phone, tablet and desktop sizes.
* [ ] No secrets, tokens or API keys appear in the page's code or in the browser's Network tab.
* [ ] Another team member can change the brand details in one place and the whole page updates.

---

## 🧯 Troubleshooting Quick Guide

| Problem | Likely cause | What to do |
|---|---|---|
| The page spins forever | A workflow branch ends without a Respond to Webhook node | Make every path end at the Respond to Webhook node |
| "Could not reach the service" | Workflow not published, or the Test URL is used after the test window closes | Publish the workflow and use the Production URL |
| The browser blocks the request (CORS) | Webhook does not allow your page's address | Add your page's address under the Webhook node's Allowed Origins, or serve the page and the webhook from the same address |
| The report looks like plain text | The response was wrapped in extra JSON or arrays | Ask the AI to extract the text from that response shape |
| Empty report | The agent output field name differs from what the Respond node sends | Match the field name used in the Respond to Webhook node |
| Timeout on large pull requests | Very large reviews take longer than the wait limit | Increase the wait limit, or ask the agent to review in batches |

---

## 🎨 Summary of Architecture & Technologies Used
- **Frontend core:** HTML5 and modern JavaScript (async/await, Fetch API, form validation, a small built-in markdown formatter). No third-party scripts are needed.
- **Design system:** Pure CSS with brand variables, flexbox and grid layouts, responsive breakpoints, light and dark themes, and reduced-motion support.
- **Typography:** Web fonts chosen to match [ORGANIZATION NAME] branding.
- **Backend integration:** An n8n workflow exposed as a webhook (`POST /webhook/github_code_reviewer`). It starts with a **Webhook** node, runs the GitHub Code Reviewer Agent, and finishes with a **Respond to Webhook** node.
- **Security:** GitHub and AI credentials stay inside n8n. The page only sends the pull request link and the chosen focus areas.
