const HISTORY_STORAGE_KEY = "mvm-code-review-history";
const THEME_STORAGE_KEY = "mvm-code-review-theme";
const toastRegion = document.querySelector("#toast-region");
let toastTimer;

function showToast(message) {
  toastRegion.textContent = message;
  toastRegion.classList.add("visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toastRegion.classList.remove("visible"), 3000);
}

function isSupportedFileUrl(fileUrl) {
  return /^https:\/\/github\.com\/[^/\s]+\/[^/\s]+\/blob\/[^/\s]+\/.+$/i.test(fileUrl) ||
    /^https:\/\/raw\.githubusercontent\.com\/[^/\s]+\/[^/\s]+\/[^/\s]+\/.+$/i.test(fileUrl);
}

function escapeXml(value) {
  return value.replace(/[<>&"']/g, (character) => ({
    "<": "&lt;",
    ">": "&gt;",
    "&": "&amp;",
    '"': "&quot;",
    "'": "&apos;",
  })[character]);
}

const settings = window.BRAND_SETTINGS;

if (settings) {
  const root = document.documentElement;

  root.style.setProperty("--primary", settings.primaryColor);
  root.style.setProperty("--secondary", settings.secondaryColor);
  root.style.setProperty("--accent", settings.accentColor);
  root.style.setProperty("--success", settings.successColor);
  root.style.setProperty("--warning", settings.warningColor);
  root.style.setProperty("--error", settings.errorColor);
  root.style.setProperty("--heading-font", `"${settings.headingFont}", "Segoe UI", sans-serif`);
  root.style.setProperty("--body-font", `"${settings.bodyFont}", "Segoe UI", sans-serif`);
  root.style.setProperty("--code-font", settings.codeFont);

  document.title = `${settings.organizationName} — ${settings.productName}`;
  const description = `Review GitHub source files with ${settings.productName} by ${settings.organizationName}.`;
  document.querySelector('meta[name="description"]').setAttribute("content", description);
  document.querySelector('meta[property="og:title"]').setAttribute("content", document.title);
  document.querySelector('meta[property="og:description"]').setAttribute("content", description);
  const productTitle = document.querySelector("#product-title");
  if (productTitle) productTitle.textContent = settings.productName;
  const tagline = document.querySelector("#tagline");
  if (tagline) tagline.textContent = settings.tagline;
  document.querySelector("#header-logo").textContent = settings.logo;
  document.querySelector("#header-organization").textContent = settings.organizationName;
  document.querySelector("#header-product").textContent = settings.productName;
  document.querySelector("#header-tagline").textContent = settings.tagline;
  document.querySelector("#user-avatar").textContent = settings.userInitials;
  document.querySelector("#footer-logo").textContent = settings.logo;
  document.querySelector("#footer-organization").textContent = settings.organizationName;
  document.querySelector("#copyright-text").textContent = settings.copyrightText;
  document.querySelector("#support-contact").textContent = settings.supportContact;
  document.querySelector("#print-organization-name").textContent = settings.organizationName;
  document.querySelector('meta[name="theme-color"]').setAttribute("content", settings.primaryColor);
  const faviconColor = /^#[\da-f]{6}$/i.test(settings.primaryColor) ? settings.primaryColor : "#4F46E5";
  const faviconInitials = escapeXml(settings.logo.slice(0, 3));
  const faviconSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="${faviconColor}"/><text x="32" y="41" fill="#ffffff" font-family="Arial,sans-serif" font-size="21" font-weight="700" text-anchor="middle">${faviconInitials}</text></svg>`;
  document.querySelector("#brand-favicon").href = `data:image/svg+xml,${encodeURIComponent(faviconSvg)}`;

  const footerLinks = document.querySelector("#footer-links");
  footerLinks.replaceChildren(
    ...settings.footerLinks.map((label) => {
      const link = document.createElement("a");
      link.href = "#";
      link.textContent = label;
      return link;
    })
  );
}

const themeToggle = document.querySelector("#theme-toggle");
const themeToggleLabel = document.querySelector("#theme-toggle-label");
const systemThemeQuery = window.matchMedia("(prefers-color-scheme: dark)");
let savedTheme = null;

try {
  savedTheme = localStorage.getItem(THEME_STORAGE_KEY);
} catch (error) {
  showToast(`Theme preference could not be read: ${error.message}`);
}
if (savedTheme !== "light" && savedTheme !== "dark") savedTheme = null;

function setTheme(theme, persist = false) {
  document.documentElement.dataset.theme = theme;
  themeToggle.setAttribute("aria-pressed", String(theme === "dark"));
  themeToggle.setAttribute("aria-label", `Switch to ${theme === "dark" ? "light" : "dark"} theme`);
  themeToggleLabel.textContent = theme === "dark" ? "Light" : "Dark";

  if (persist) {
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
      savedTheme = theme;
    } catch (error) {
      showToast(`Theme preference could not be saved: ${error.message}`);
    }
  }
}

setTheme(savedTheme === "light" || savedTheme === "dark" ? savedTheme : systemThemeQuery.matches ? "dark" : "light");

themeToggle.addEventListener("click", () => {
  setTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark", true);
});

systemThemeQuery.addEventListener("change", (event) => {
  if (!savedTheme) setTheme(event.matches ? "dark" : "light");
});

const serviceStatus = document.querySelector("#service-status");
const serviceStatusText = document.querySelector("#service-status-text");

function updateServiceStatus(status) {
  serviceStatus.classList.remove("checking", "online", "offline");
  serviceStatus.classList.add(status);
  serviceStatusText.textContent = status === "online"
    ? "Reviewer Online"
    : status === "offline"
      ? "Reviewer Offline"
      : "Checking reviewer...";
}

async function checkReviewerAvailability() {
  updateServiceStatus("checking");
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(settings.healthCheckUrl, {
      method: "GET",
      cache: "no-store",
      signal: controller.signal,
    });
    updateServiceStatus(response.ok ? "online" : "offline");
  } catch {
    updateServiceStatus("offline");
  } finally {
    window.clearTimeout(timeoutId);
  }
}

checkReviewerAvailability();
window.setInterval(checkReviewerAvailability, 60000);

function loadReviewHistory() {
  try {
    const savedHistory = JSON.parse(localStorage.getItem(HISTORY_STORAGE_KEY) || "[]");
    if (!Array.isArray(savedHistory)) throw new Error("Stored history is not a list.");
    return savedHistory
      .filter((entry) =>
        entry &&
        typeof entry.fileUrl === "string" &&
        isSupportedFileUrl(entry.fileUrl) &&
        (entry.status === "Complete" || entry.status === "Failed") &&
        typeof entry.reviewedAt === "string" &&
        typeof entry.review === "string" &&
        typeof entry.errorMessage === "string"
      )
      .slice(0, 10);
  } catch (error) {
    showToast(`Review history could not be loaded: ${error.message}`);
    return [];
  }
}

let reviewHistory = loadReviewHistory();

function saveReviewHistory(fileUrl, status, review, errorMessage = "") {
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    fileUrl,
    status,
    review,
    errorMessage,
    reviewedAt: new Date().toISOString(),
  };
  reviewHistory = [entry, ...reviewHistory].slice(0, 10);

  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(reviewHistory));
  } catch (error) {
    showToast(`Review completed, but history could not be saved: ${error.message}`);
  }

  renderReviewHistory();
  return entry;
}

function renderReviewHistory() {
  const historyList = document.querySelector("#history-list");
  historyList.replaceChildren();

  if (!reviewHistory.length) {
    const emptyState = document.createElement("p");
    emptyState.className = "history-empty";
    emptyState.textContent = "No reviews yet. Completed and failed reviews will appear here.";
    historyList.append(emptyState);
    return;
  }

  reviewHistory.forEach((entry) => {
    const row = document.createElement("article");
    row.className = "history-entry";
    const main = document.createElement("div");
    main.className = "history-entry-main";
    const url = document.createElement("span");
    url.className = "history-entry-url";
    url.textContent = entry.fileUrl;
    const meta = document.createElement("div");
    meta.className = "history-entry-meta";
    const status = document.createElement("span");
    status.className = `history-status ${entry.status === "Complete" ? "complete" : "failed"}`;
    status.textContent = entry.status;
    const date = document.createElement("time");
    date.dateTime = entry.reviewedAt;
    const parsedDate = new Date(entry.reviewedAt);
    date.textContent = Number.isNaN(parsedDate.getTime()) ? "Unknown date" : parsedDate.toLocaleString();
    meta.append(status, date);
    main.append(url, meta);

    const openButton = document.createElement("button");
    openButton.type = "button";
    openButton.className = "history-open-button";
    openButton.dataset.historyId = entry.id;
    openButton.textContent = entry.status === "Complete" ? "Open report" : "View status";
    row.append(main, openButton);
    historyList.append(row);
  });
}

const historyDialog = document.querySelector("#review-history");
const historyList = document.querySelector("#history-list");
let historyTrigger = null;

document.querySelectorAll("[data-open-history]").forEach((link) => {
  link.addEventListener("click", (event) => {
    event.preventDefault();
    historyTrigger = link;
    closeMobileMenu();
    renderReviewHistory();
    historyDialog.showModal();
  });
});

document.querySelector("#close-history").addEventListener("click", () => historyDialog.close());
historyDialog.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    event.preventDefault();
    historyDialog.close();
  }
});
historyDialog.addEventListener("close", () => {
  if (historyTrigger && mobileNavigation.contains(historyTrigger) && mobileNavigation.hidden) {
    menuButton.focus();
  } else if (historyTrigger) {
    historyTrigger.focus();
  }
  historyTrigger = null;
});
historyDialog.addEventListener("click", (event) => {
  if (event.target === historyDialog) historyDialog.close();
});

historyList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-history-id]");
  if (!button) return;
  const entry = reviewHistory.find((item) => item.id === button.dataset.historyId);
  if (!entry) {
    showToast("That history item is no longer available.");
    return;
  }

  historyDialog.close();
  sourceFileInput.value = entry.fileUrl;
  if (entry.status !== "Complete") {
    showError("This review did not complete.", entry.errorMessage || "Try the review again.");
    return;
  }

  lastReviewText = entry.review;
  lastReviewedSourceUrl = entry.fileUrl;
  lastReviewFinishedAt = new Date(entry.reviewedAt);
  document.querySelector("#review-output").replaceChildren(renderMarkdown(entry.review));
  const sourceLink = document.querySelector("#reviewed-source-url");
  sourceLink.href = entry.fileUrl;
  sourceLink.textContent = entry.fileUrl;
  document.querySelector("#review-finished-at").textContent = `Reviewed ${lastReviewFinishedAt.toLocaleString()}`;
  document.querySelector("#print-review-date").textContent = lastReviewFinishedAt.toLocaleString();
  document.querySelector("#report-action-status").textContent = "";
  showWorkspaceState("success");
});

document.querySelector("#clear-history").addEventListener("click", () => {
  try {
    localStorage.removeItem(HISTORY_STORAGE_KEY);
    reviewHistory = [];
    renderReviewHistory();
    showToast("Review history cleared.");
  } catch (error) {
    showToast(`Review history could not be cleared: ${error.message}`);
  }
});

const menuButton = document.querySelector("#menu-button");
const mobileNavigation = document.querySelector("#mobile-navigation");

function closeMobileMenu() {
  mobileNavigation.hidden = true;
  menuButton.setAttribute("aria-expanded", "false");
  menuButton.setAttribute("aria-label", "Open navigation menu");
}

menuButton.addEventListener("click", () => {
  const isOpen = menuButton.getAttribute("aria-expanded") === "true";
  mobileNavigation.hidden = isOpen;
  menuButton.setAttribute("aria-expanded", String(!isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Open navigation menu" : "Close navigation menu");
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !mobileNavigation.hidden) {
    closeMobileMenu();
    menuButton.focus();
  }
});

const reviewForm = document.querySelector(".review-request-form");
const sourceFileInput = document.querySelector("#source-file-url");
const requestPanel = document.querySelector(".request-panel");
const fieldError = document.querySelector("#source-file-error");
const workspaceState = document.querySelector("#workspace-state");
const completeBadge = document.querySelector("#complete-badge");
const focusError = document.querySelector("#focus-error");
const sourceFileErrorText = document.querySelector("#source-file-error-text");
const submitButton = reviewForm.querySelector('button[type="submit"]');
const stateButtons = document.querySelectorAll("[data-state]");
const stateViews = document.querySelectorAll("[data-view]");
const loadingMessages = ["Reading source file...", "Fetching file contents...", "Checking code quality...", "Scanning for security risks...", "Preparing recommendations..."];
let loadingTimer;
let lastReviewText = "";
let lastReviewedSourceUrl = "";
let lastReviewFinishedAt = null;

function showWorkspaceState(state, validationKind = "sourceFile") {
  workspaceState.classList.add("switching");
  window.setTimeout(() => {
    stateViews.forEach((view) => { view.hidden = view.dataset.view !== state; });
    stateButtons.forEach((button) => { button.classList.toggle("active", button.dataset.state === state); });
    completeBadge.hidden = state !== "success";

    const isValidation = state === "validation";
    const invalidInput = isValidation && validationKind === "sourceFile";
    sourceFileInput.classList.toggle("invalid", invalidInput);
    fieldError.hidden = !invalidInput;
    focusError.hidden = !(isValidation && validationKind === "focus");
    requestPanel.classList.remove("shake");
    if (isValidation) {
      void requestPanel.offsetWidth;
      requestPanel.classList.add("shake");
    }

    window.clearInterval(loadingTimer);
    if (state === "loading") {
      let loadingIndex = 0;
      document.querySelector("#loading-message").textContent = loadingMessages[0];
      loadingTimer = window.setInterval(() => {
        loadingIndex = (loadingIndex + 1) % loadingMessages.length;
        document.querySelector("#loading-message").textContent = loadingMessages[loadingIndex];
      }, 1500);
    }
    workspaceState.classList.remove("switching");
  }, 180);
}

stateButtons.forEach((button) => {
  button.addEventListener("click", () => showWorkspaceState(button.dataset.state));
});

function setFormBusy(isBusy) {
  reviewForm.querySelectorAll("input, button").forEach((control) => {
    control.disabled = isBusy;
  });
  submitButton.textContent = isBusy ? "Reviewing..." : "Review Code";
}

function extractReviewText(value, depth = 0) {
  if (depth > 8 || value == null) return "";
  if (typeof value === "string") {
    const text = value.trim();
    if (!text) return "";
    try {
      return extractReviewText(JSON.parse(text), depth + 1);
    } catch {
      return text;
    }
  }
  if (Array.isArray(value)) {
    return value.map((item) => extractReviewText(item, depth + 1)).filter(Boolean).join("\n\n");
  }
  if (typeof value === "object") {
    for (const key of ["review", "output", "text", "content", "message"]) {
      if (key in value) {
        const text = extractReviewText(value[key], depth + 1);
        if (text) return text;
      }
    }
    for (const nested of Object.values(value)) {
      const text = extractReviewText(nested, depth + 1);
      if (text) return text;
    }
  }
  return "";
}

async function readResponseText(response) {
  const rawBody = await response.text();
  if (!rawBody.trim()) return "";
  try {
    return extractReviewText(JSON.parse(rawBody));
  } catch {
    return rawBody.trim();
  }
}

function appendInlineMarkdown(parent, text) {
  const tokenPattern = /(`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|\*\*.+?\*\*|__.+?__|\*[^*]+\*|_[^_]+_|\b(?:critical|high|medium|low|info)\b)/gi;
  let cursor = 0;

  for (const match of text.matchAll(tokenPattern)) {
    const token = match[0];
    if (match.index > cursor) parent.append(document.createTextNode(text.slice(cursor, match.index)));

    if (token.startsWith("`")) {
      const code = document.createElement("code");
      code.className = "inline-code";
      code.textContent = token.slice(1, -1);
      parent.append(code);
    } else if (token.startsWith("[")) {
      const linkMatch = token.match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);
      if (linkMatch) {
        try {
          const href = new URL(linkMatch[2]);
          if (href.protocol === "https:" || href.protocol === "http:") {
            const link = document.createElement("a");
            link.href = href.href;
            link.target = "_blank";
            link.rel = "noopener noreferrer";
            link.textContent = linkMatch[1];
            parent.append(link);
          } else {
            parent.append(document.createTextNode(token));
          }
        } catch {
          parent.append(document.createTextNode(token));
        }
      }
    } else if (token.startsWith("**") || token.startsWith("__")) {
      const strong = document.createElement("strong");
      appendInlineMarkdown(strong, token.slice(2, -2));
      parent.append(strong);
    } else if (token.startsWith("*") || token.startsWith("_")) {
      const emphasis = document.createElement("em");
      appendInlineMarkdown(emphasis, token.slice(1, -1));
      parent.append(emphasis);
    } else {
      const severity = token.toLowerCase();
      const badge = document.createElement("span");
      badge.className = `severity-badge severity-${severity}`;
      badge.textContent = token;
      parent.append(badge);
    }

    cursor = match.index + token.length;
  }

  if (cursor < text.length) parent.append(document.createTextNode(text.slice(cursor)));
}

function markdownCells(line) {
  return line.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((cell) => cell.trim());
}

function isMarkdownTableSeparator(line) {
  return /^\|?\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)*\|?$/.test(line.trim());
}

function renderMarkdown(markdown) {
  const container = document.createElement("div");
  container.className = "markdown-content";
  const lines = markdown.replace(/\r\n?/g, "\n").split("\n");
  let index = 0;

  const isListItem = (line) => /^\s*(?:[-*+]|\d+[.)])\s+/.test(line);
  const isHeading = (line) => /^#{1,6}\s+/.test(line);
  const isFence = (line) => /^\s*```/.test(line);
  const isTable = (line, lineIndex) => line.includes("|") && isMarkdownTableSeparator(lines[lineIndex + 1] || "");

  while (index < lines.length) {
    const line = lines[index];
    if (!line.trim()) {
      index += 1;
      continue;
    }

    if (isFence(line)) {
      const language = line.trim().slice(3).trim().split(/\s+/)[0] || "Code";
      const codeLines = [];
      index += 1;
      while (index < lines.length && !isFence(lines[index])) {
        codeLines.push(lines[index]);
        index += 1;
      }
      if (index < lines.length) index += 1;

      const block = document.createElement("section");
      block.className = "code-block";
      const header = document.createElement("div");
      header.className = "code-block-header";
      const languageLabel = document.createElement("span");
      languageLabel.textContent = language;
      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.className = "copy-code-button";
      copyButton.dataset.action = "copy-code";
      copyButton.textContent = "Copy";
      const pre = document.createElement("pre");
      const code = document.createElement("code");
      code.textContent = codeLines.join("\n");
      header.append(languageLabel, copyButton);
      pre.append(code);
      block.append(header, pre);
      container.append(block);
      continue;
    }

    if (isHeading(line)) {
      const headingMatch = line.match(/^(#{1,6})\s+(.+)$/);
      const heading = document.createElement(`h${Math.min(headingMatch[1].length + 2, 6)}`);
      appendInlineMarkdown(heading, headingMatch[2]);
      container.append(heading);
      index += 1;
      continue;
    }

    if (/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/.test(line)) {
      container.append(document.createElement("hr"));
      index += 1;
      continue;
    }

    if (isTable(line, index)) {
      const rows = [markdownCells(line)];
      index += 2;
      while (index < lines.length && lines[index].includes("|") && lines[index].trim()) {
        rows.push(markdownCells(lines[index]));
        index += 1;
      }

      const wrapper = document.createElement("div");
      wrapper.className = "markdown-table-wrap";
      wrapper.setAttribute("role", "region");
      wrapper.setAttribute("aria-label", "Scrollable review table");
      wrapper.tabIndex = 0;
      const table = document.createElement("table");
      table.className = "markdown-table";
      const head = document.createElement("thead");
      const headerRow = document.createElement("tr");
      rows[0].forEach((value) => {
        const cell = document.createElement("th");
        cell.scope = "col";
        appendInlineMarkdown(cell, value);
        headerRow.append(cell);
      });
      head.append(headerRow);
      table.append(head);
      if (rows.length > 1) {
        const body = document.createElement("tbody");
        rows.slice(1).forEach((row) => {
          const tableRow = document.createElement("tr");
          rows[0].forEach((_, cellIndex) => {
            const cell = document.createElement("td");
            appendInlineMarkdown(cell, row[cellIndex] || "");
            tableRow.append(cell);
          });
          body.append(tableRow);
        });
        table.append(body);
      }
      wrapper.append(table);
      container.append(wrapper);
      continue;
    }

    if (isListItem(line)) {
      const ordered = /^\s*\d+[.)]\s+/.test(line);
      const list = document.createElement(ordered ? "ol" : "ul");
      while (index < lines.length && isListItem(lines[index]) && /^\s*\d+[.)]\s+/.test(lines[index]) === ordered) {
        const itemText = lines[index].replace(/^\s*(?:[-*+]|\d+[.)])\s+/, "");
        const item = document.createElement("li");
        appendInlineMarkdown(item, itemText);
        list.append(item);
        index += 1;
      }
      container.append(list);
      continue;
    }

    const paragraphLines = [];
    while (
      index < lines.length &&
      lines[index].trim() &&
      !isHeading(lines[index]) &&
      !isFence(lines[index]) &&
      !isListItem(lines[index]) &&
      !isTable(lines[index], index) &&
      !/^\s*(?:-{3,}|\*{3,}|_{3,})\s*$/.test(lines[index])
    ) {
      paragraphLines.push(lines[index]);
      index += 1;
    }
    const paragraph = document.createElement("p");
    paragraphLines.forEach((paragraphLine, lineIndex) => {
      if (lineIndex) paragraph.append(document.createElement("br"));
      appendInlineMarkdown(paragraph, paragraphLine);
    });
    container.append(paragraph);
  }

  return container;
}

function showError(title, message) {
  document.querySelector("#error-title").textContent = title;
  document.querySelector("#error-message").textContent = message;
  showWorkspaceState("error");
}

function validateRequest(fileUrl, focusAreas) {
  if (!fileUrl) {
    showWorkspaceState("validation", "sourceFile");
    sourceFileErrorText.textContent = "Please enter a GitHub source file URL.";
    return false;
  }
  const isBlobFile = /^https:\/\/github\.com\/[^/\s]+\/[^/\s]+\/blob\/[^/\s]+\/.+$/i.test(fileUrl);
  const isRawFile = /^https:\/\/raw\.githubusercontent\.com\/[^/\s]+\/[^/\s]+\/[^/\s]+\/.+$/i.test(fileUrl);
  if (!isBlobFile && !isRawFile) {
    showWorkspaceState("validation", "sourceFile");
    sourceFileErrorText.textContent = "Enter a GitHub blob file URL or a raw.githubusercontent.com file URL.";
    return false;
  }
  if (focusAreas.length === 0) {
    showWorkspaceState("validation", "focus");
    return false;
  }
  return true;
}

async function submitReview() {
  const fileUrl = sourceFileInput.value.trim();
  const focusAreas = [...reviewForm.querySelectorAll('input[name="focus"]:checked')].map((input) => input.value);
  if (!validateRequest(fileUrl, focusAreas)) return;

  setFormBusy(true);
  showWorkspaceState("loading");
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 180000);

  try {
    const response = await fetch(window.BRAND_SETTINGS.webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileUrl, focusAreas }),
      signal: controller.signal,
    });
    const review = await readResponseText(response);

    if (!response.ok) {
      if (response.status >= 500) {
        const message = "Please try again in a moment.";
        saveReviewHistory(fileUrl, "Failed", "", `The review service had a problem. ${message}`);
        showError("The review service had a problem.", message);
      } else {
        const message = review || `The service returned an error (${response.status}).`;
        saveReviewHistory(fileUrl, "Failed", "", message);
        showError("The review request was rejected.", message);
      }
      return;
    }

    if (!review) {
      saveReviewHistory(fileUrl, "Failed", "", "The review came back empty. Please try again.");
      showError("The review came back empty.", "Please try again.");
      return;
    }

    saveReviewHistory(fileUrl, "Complete", review);
    lastReviewText = review;
    lastReviewedSourceUrl = fileUrl;
    lastReviewFinishedAt = new Date();
    document.querySelector("#review-output").replaceChildren(renderMarkdown(review));
    const sourceLink = document.querySelector("#reviewed-source-url");
    sourceLink.href = fileUrl;
    sourceLink.textContent = fileUrl;
    document.querySelector("#review-finished-at").textContent = `Reviewed ${lastReviewFinishedAt.toLocaleString()}`;
    document.querySelector("#print-review-date").textContent = lastReviewFinishedAt.toLocaleString();
    showWorkspaceState("success");
  } catch (error) {
    if (error.name === "AbortError") {
      saveReviewHistory(fileUrl, "Failed", "", "The request timed out after 3 minutes. Please try again.");
      showError("The review took too long.", "The request timed out after 3 minutes. Please try again.");
    } else {
      saveReviewHistory(fileUrl, "Failed", "", "Please check your connection and try again.");
      showError("We couldn't reach the review service.", "Please check your connection and try again.");
    }
  } finally {
    window.clearTimeout(timeoutId);
    setFormBusy(false);
  }
}

reviewForm.addEventListener("submit", (event) => {
  event.preventDefault();
  submitReview();
});

document.querySelector(".try-again-button").addEventListener("click", submitReview);

sourceFileInput.addEventListener("input", () => {
  if (sourceFileInput.value.trim()) {
    sourceFileInput.classList.remove("invalid");
    fieldError.hidden = true;
  }
});

reviewForm.querySelectorAll('input[name="focus"]').forEach((input) => {
  input.addEventListener("change", () => {
    if (reviewForm.querySelector('input[name="focus"]:checked')) focusError.hidden = true;
  });
});

async function copyTextToClipboard(text) {
  if (!navigator.clipboard || !navigator.clipboard.writeText) {
    throw new Error("Clipboard access is unavailable in this browser context.");
  }
  await navigator.clipboard.writeText(text);
}

function showActionStatus(message) {
  document.querySelector("#report-action-status").textContent = message;
}

async function copyReportText(text, button) {
  try {
    await copyTextToClipboard(text);
    showActionStatus("Copied to clipboard.");
    showToast("Copied to clipboard.");
    if (button) {
      const originalLabel = button.textContent;
      button.textContent = "Copied";
      window.setTimeout(() => { button.textContent = originalLabel; }, 1400);
    }
  } catch (error) {
    showActionStatus(`Copy failed: ${error.message}`);
  }
}

document.querySelector("#review-output").addEventListener("click", (event) => {
  const button = event.target.closest('[data-action="copy-code"]');
  if (!button) return;
  const code = button.closest(".code-block").querySelector("code").textContent;
  copyReportText(code, button);
});

document.querySelector(".report-actions").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  if (button.dataset.action === "copy-report") {
    copyReportText(lastReviewText, button);
  } else if (button.dataset.action === "download-report") {
    const sourceName = new URL(lastReviewedSourceUrl).pathname.split("/").pop() || "review";
    const safeName = sourceName.replace(/[^\w.-]+/g, "-");
    const downloadLink = document.createElement("a");
    const reportBlob = new Blob([lastReviewText], { type: "text/markdown;charset=utf-8" });
    const objectUrl = URL.createObjectURL(reportBlob);
    downloadLink.href = objectUrl;
    downloadLink.download = `${safeName}-review.md`;
    downloadLink.click();
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
    showActionStatus("Markdown report downloaded.");
    showToast("Markdown report downloaded.");
  } else if (button.dataset.action === "print-report") {
    window.print();
  } else if (button.dataset.action === "new-review") {
    reviewForm.reset();
    sourceFileInput.classList.remove("invalid");
    fieldError.hidden = true;
    focusError.hidden = true;
    lastReviewText = "";
    lastReviewedSourceUrl = "";
    lastReviewFinishedAt = null;
    document.querySelector("#review-output").replaceChildren();
    document.querySelector("#report-action-status").textContent = "";
    showWorkspaceState("waiting");
    sourceFileInput.focus();
    showToast("Ready for a new review.");
  }
});
